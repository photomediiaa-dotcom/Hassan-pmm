import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hassan.productionapp',
  appName: 'Hassan Production',
  webDir: 'dist',
  plugins: {
    GoogleAuth: {
      scopes: ['profile', 'email'],
      serverClientId: 'YOUR_SERVER_CLIENT_ID', // Replace with your Firebase Web Client ID
      forceCodeForRefreshToken: true,
    },
  },
  server: {
    androidScheme: 'https'
  }
};

export default config;
