import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore, initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from "firebase/firestore";

const firebaseConfig = {
  projectId: "applied-crossbar-zw2h4",
  appId: "1:1069259891440:web:324e6ae98272ac764a9835",
  apiKey: "AIzaSyAaPgVP6a88L_9ciolup1vqluaXEa86seI",
  authDomain: "applied-crossbar-zw2h4.firebaseapp.com",
  storageBucket: "applied-crossbar-zw2h4.firebasestorage.app",
  messagingSenderId: "1069259891440",
  measurementId: ""
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({tabManager: persistentMultipleTabManager()})
}, "ai-studio-51fc1131-cb1e-48a4-89c4-f05fa19afcf9");
