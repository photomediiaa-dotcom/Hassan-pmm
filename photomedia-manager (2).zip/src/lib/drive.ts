import { getAuth, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth } from './firebase';

const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/drive');

let cachedAccessToken: string | null = null;
let isSigningIn = false;

export const connectGoogleDrive = async (): Promise<string | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get access token');
    }
    cachedAccessToken = credential.accessToken;
    return cachedAccessToken;
  } catch (error) {
    console.error('Google Drive connect error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getDriveAccessToken = (): string | null => {
  return cachedAccessToken;
};

// Drive API helpers
export const createProjectFolder = async (projectName: string, token: string) => {
  // 1. Create main folder
  const mainFolderId = await createFolder(projectName, token);
  
  // 2. Create subfolders
  const subfolders = [
    'Contracts',
    'Shot Lists',
    'Footage',
    'Drone',
    'Audio',
    'Graphics',
    'Project Files',
    'Revisions',
    'Final Delivery'
  ];

  for (const sub of subfolders) {
    await createFolder(sub, token, mainFolderId);
  }

  return mainFolderId;
};

const createFolder = async (name: string, token: string, parentId?: string) => {
  const metadata: any = {
    name,
    mimeType: 'application/vnd.google-apps.folder',
  };
  if (parentId) {
    metadata.parents = [parentId];
  }

  const res = await fetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(metadata),
  });

  if (!res.ok) {
    throw new Error('Failed to create folder');
  }

  const data = await res.json();
  return data.id;
};
