import { create } from 'zustand';
import { User } from 'firebase/auth';

export type Role = 'Super Admin' | 'Admin' | 'Production Manager' | 'Editor' | 'Camera Operator' | 'Drone Operator' | 'Designer';

export interface UserProfile {
  uid: string;
  email: string;
  role: Role;
  displayName?: string;
  phoneNumber?: string;
  photoURL?: string;
  isActive: boolean;
}

interface AuthState {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  setUser: (user: User | null) => void;
  setProfile: (profile: UserProfile | null) => void;
  setLoading: (loading: boolean) => void;
  isSuperAdmin: () => boolean;
  isAdmin: () => boolean;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  profile: null,
  loading: true,
  setUser: (user) => set({ user }),
  setProfile: (profile) => set({ profile }),
  setLoading: (loading) => set({ loading }),
  isSuperAdmin: () => get().profile?.role === 'Super Admin',
  isAdmin: () => {
    const role = get().profile?.role;
    return role === 'Super Admin' || role === 'Admin';
  },
}));
