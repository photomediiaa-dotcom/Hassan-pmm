import { Calendar as CalendarIcon } from 'lucide-react';

export default function Calendar() {
  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex items-center justify-between shrink-0">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <CalendarIcon className="w-6 h-6 text-primary" />
          التقويم
        </h1>
        <div className="flex bg-card border border-border rounded-md overflow-hidden">
          <button className="px-4 py-2 bg-primary/10 text-primary font-medium">يومي</button>
          <button className="px-4 py-2 hover:bg-border/50 text-foreground/70">أسبوعي</button>
          <button className="px-4 py-2 hover:bg-border/50 text-foreground/70">شهري</button>
        </div>
      </div>
      
      <div className="bg-card border border-border rounded-lg p-8 flex-1 flex items-center justify-center text-foreground/60">
        سيتم عرض تقويم مواعيد التصوير، جدول الفريق، وحجوزات المعدات هنا...
      </div>
    </div>
  );
}
