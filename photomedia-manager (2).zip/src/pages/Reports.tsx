import { BarChart } from 'lucide-react';

export default function Reports() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <BarChart className="w-6 h-6 text-primary" />
          التقارير
        </h1>
        <button className="bg-primary hover:bg-primary-gold-dark text-primary-foreground px-4 py-2 rounded-md font-medium transition-colors">
          تصدير التقرير
        </button>
      </div>
      <div className="bg-card border border-border rounded-lg p-8 text-center text-foreground/60">التقارير والإحصائيات...</div>
    </div>
  );
}
