import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { signInWithPopup, signInWithRedirect, GoogleAuthProvider } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useAuthStore } from '../store/authStore';
import { Camera } from 'lucide-react';
import { Capacitor } from '@capacitor/core';

export default function Login() {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { setProfile } = useAuthStore();

  const handleGoogleLogin = async () => {
    setError('');
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      if (Capacitor.isNativePlatform()) {
        await signInWithRedirect(auth, provider);
        return;
      }
      const userCred = await signInWithPopup(auth, provider);
      
      const docRef = doc(db, 'users', userCred.user.uid);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const profileData = docSnap.data();
        if (!profileData.isActive && userCred.user.email !== 'photomediiaa@gmail.com') {
          throw new Error('الحساب غير مفعل. يرجى مراجعة الإدارة.');
        }
        setProfile({ uid: userCred.user.uid, ...profileData } as any);
        navigate('/');
      } else {
        // Auto-create for Google sign in
        const newProfile = {
          uid: userCred.user.uid,
          email: userCred.user.email,
          displayName: userCred.user.displayName || 'مستخدم',
          role: userCred.user.email === 'photomediiaa@gmail.com' ? 'Super Admin' : 'Editor',
          isActive: true
        };
        await setDoc(docRef, newProfile);
        setProfile(newProfile as any);
        navigate('/');
      }
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/popup-closed-by-user') {
         // User closed the popup, do nothing
      } else if (err.code === 'auth/network-request-failed') {
        setError('فشل الاتصال بالخادم. يرجى التحقق من اتصالك بالإنترنت.');
      } else {
        setError(err.message || 'خطأ في تسجيل الدخول عبر Google.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center py-12 sm:px-6 lg:px-8 rtl">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center text-primary">
          <Camera className="w-16 h-16" />
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-foreground">
          PhotoMedia Manager
        </h2>
        <p className="mt-2 text-center text-sm text-foreground/60">
          نظام إدارة الإنتاج الإعلامي
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-card py-8 px-4 shadow sm:rounded-lg sm:px-10 border border-border">
          {error && (
            <div className="mb-6 bg-red-50 dark:bg-red-900/30 text-red-600 p-3 rounded-md text-sm border border-red-200 dark:border-red-800">
              {error}
            </div>
          )}

          <div className="mt-2">
            <button
              onClick={handleGoogleLogin}
              disabled={loading}
              className="w-full flex justify-center items-center gap-3 py-3 px-4 border border-border rounded-md shadow-sm text-sm font-medium text-foreground bg-background hover:bg-border/50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 transition-colors"
            >
              <svg className="w-6 h-6" viewBox="0 0 24 24">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
                <path d="M1 1h22v22H1z" fill="none" />
              </svg>
              {loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول باستخدام Google'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

