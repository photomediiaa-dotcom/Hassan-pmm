import { Film, Plus, Filter, Search, MoreVertical } from 'lucide-react';

export default function Projects() {
  const projects = [
    { id: 1, name: 'حفل تخرج جامعة الملك سعود', client: 'جامعة الملك سعود', date: '2026-07-01', status: 'مجدول', budget: '25,000 ر.س' },
    { id: 2, name: 'إعلان مطعم البيك', client: 'البيك', date: '2026-06-25', status: 'قيد المونتاج', budget: '15,000 ر.س' },
    { id: 3, name: 'تغطية مقيال زفاف', client: 'عائلة الراجحي', date: '2026-06-20', status: 'تصوير', budget: '30,000 ر.س' },
  ];

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex items-center justify-between shrink-0">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Film className="w-6 h-6 text-primary" />
          المشاريع
        </h1>
        <button className="bg-primary hover:bg-primary-gold-dark text-primary-foreground px-4 py-2 rounded-md font-medium transition-colors flex items-center gap-2">
          <Plus className="w-5 h-5" />
          مشروع جديد
        </button>
      </div>
      
      <div className="bg-card border border-border rounded-lg p-4 shrink-0 flex gap-4">
        <div className="relative flex-1">
          <Search className="w-5 h-5 absolute right-3 top-1/2 -translate-y-1/2 text-foreground/50" />
          <input 
            type="text" 
            placeholder="البحث في المشاريع..." 
            className="w-full bg-background border border-border rounded-md py-2 pr-10 pl-4 focus:outline-none focus:border-primary"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border border-border rounded-md hover:bg-border/50 transition-colors">
          <Filter className="w-5 h-5" />
          تصفية
        </button>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden flex-1">
        <table className="w-full text-right">
          <thead className="bg-background border-b border-border text-sm">
            <tr>
              <th className="px-6 py-4 font-semibold text-foreground/70">اسم المشروع</th>
              <th className="px-6 py-4 font-semibold text-foreground/70">العميل</th>
              <th className="px-6 py-4 font-semibold text-foreground/70">تاريخ التصوير</th>
              <th className="px-6 py-4 font-semibold text-foreground/70">الحالة</th>
              <th className="px-6 py-4 font-semibold text-foreground/70">الميزانية</th>
              <th className="px-6 py-4 font-semibold text-foreground/70">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {projects.map((project) => (
              <tr key={project.id} className="hover:bg-background/50 transition-colors">
                <td className="px-6 py-4 font-medium">{project.name}</td>
                <td className="px-6 py-4 text-foreground/70">{project.client}</td>
                <td className="px-6 py-4 text-foreground/70">{project.date}</td>
                <td className="px-6 py-4">
                  <span className="px-3 py-1 bg-primary/10 text-primary text-xs rounded-full font-medium">
                    {project.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-foreground/70">{project.budget}</td>
                <td className="px-6 py-4">
                  <button className="text-foreground/50 hover:text-foreground">
                    <MoreVertical className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
