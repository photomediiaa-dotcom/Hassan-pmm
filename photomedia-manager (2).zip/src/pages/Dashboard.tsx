import { useAuthStore } from "../store/authStore";
import { Film, CheckCircle, Clock, Calendar as CalendarIcon, DollarSign, Activity } from 'lucide-react';

export default function Dashboard() {
  const { profile } = useAuthStore();

  const stats = [
    { name: 'مشاريع نشطة', value: '12', icon: Film, color: 'text-blue-500', bg: 'bg-blue-100 dark:bg-blue-900/30' },
    { name: 'مشاريع مكتملة', value: '48', icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-100 dark:bg-green-900/30' },
    { name: 'تصوير قادم', value: '3', icon: CalendarIcon, color: 'text-purple-500', bg: 'bg-purple-100 dark:bg-purple-900/30' },
    { name: 'مشاريع متأخرة', value: '1', icon: Clock, color: 'text-red-500', bg: 'bg-red-100 dark:bg-red-900/30' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">مرحباً، {profile?.displayName || 'مستخدم'}</h1>
        <div className="text-sm text-foreground/60">{new Date().toLocaleDateString('ar-SA')}</div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.name} className="bg-card border border-border rounded-lg p-6 flex items-center gap-4">
            <div className={`p-4 rounded-full ${stat.bg} ${stat.color}`}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-foreground/60">{stat.name}</p>
              <p className="text-2xl font-bold mt-1">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <div className="bg-card border border-border rounded-lg col-span-1 lg:col-span-2">
          <div className="p-6 border-b border-border flex items-center justify-between">
            <h2 className="font-bold flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              أحدث النشاطات
            </h2>
          </div>
          <div className="p-6">
            <div className="space-y-6">
              {/* Dummy data */}
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex gap-4">
                  <div className="w-2 h-2 mt-2 rounded-full bg-primary shrink-0"></div>
                  <div>
                    <p className="text-sm"><span className="font-bold">أحمد محمد</span> قام بتحديث حالة مشروع <span className="font-bold">تخرج جامعة الملك سعود</span> إلى <span className="text-primary">قيد المونتاج</span></p>
                    <p className="text-xs text-foreground/50 mt-1">منذ ساعتين</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Financial Summary */}
        <div className="bg-card border border-border rounded-lg">
          <div className="p-6 border-b border-border flex items-center justify-between">
            <h2 className="font-bold flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-primary" />
              ملخص مالي (هذا الشهر)
            </h2>
          </div>
          <div className="p-6 space-y-4">
            <div>
              <p className="text-sm text-foreground/60 mb-1">الإيرادات المتوقعة</p>
              <p className="text-2xl font-bold">145,000 ر.س</p>
            </div>
            <div>
              <p className="text-sm text-foreground/60 mb-1">المدفوعات المستلمة</p>
              <p className="text-2xl font-bold text-green-500">80,000 ر.س</p>
            </div>
            <div>
              <p className="text-sm text-foreground/60 mb-1">الدفعات المعلقة</p>
              <p className="text-2xl font-bold text-red-500">65,000 ر.س</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
