import React, { useState } from 'react';
import { Bot, Send, User, Sparkles, AlertCircle } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export default function AIAssistant() {
  const { profile } = useAuthStore();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `مرحباً بك ${profile?.displayName || ''} في المساعد الذكي لـ PhotoMedia Manager!
يمكنني مساعدتك في:
- توليد أفكار للمشاريع
- كتابة سكريبت للإعلانات
- اقتراح لقطات تصوير (Shot List)
- اقتراح موسيقى وانتقالات
- زوايا الكاميرا وحركة الدرون
كيف يمكنني مساعدتك اليوم؟`,
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setError('');

    try {
      // Create full prompt with history context
      const prompt = messages.map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join('\n') + `\nUser: ${userMessage.content}`;

      const response = await fetch('/api/ai/suggest', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ prompt: userMessage.content }) // We send the latest prompt or history, depending on logic
      });

      if (!response.ok) {
        throw new Error('فشل في الاتصال بالمساعد الذكي');
      }

      const data = await response.json();
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.text || 'عذراً، لم أتمكن من توليد الرد.'
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err: any) {
      setError(err.message || 'حدث خطأ غير متوقع');
    } finally {
      setIsLoading(false);
    }
  };

  const suggestions = [
    "اقترح لي سكريبت إعلان لمطعم برجر مدته 30 ثانية",
    "اكتب لي قائمة لقطات (Shot List) لتغطية حفل تخرج",
    "ما هي أفضل زوايا التصوير لمنتج عطر؟",
    "اقترح أفكار تصوير فيديو لحملة إعلانية لشركة عقارات"
  ];

  return (
    <div className="h-full flex flex-col space-y-4 max-w-5xl mx-auto relative">
      <div className="flex items-center gap-3 pb-4 border-b border-border shrink-0">
        <div className="p-3 rounded-full bg-primary/10 text-primary">
          <Bot className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">المساعد الذكي (AI)</h1>
          <p className="text-sm text-foreground/60">مدعوم بـ Gemini AI لخدمات الإنتاج الإعلامي</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-6 pb-20 pr-2 custom-scrollbar">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
              msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-card border border-border text-primary'
            }`}>
              {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
            </div>
            <div className={`max-w-[80%] rounded-2xl p-4 ${
              msg.role === 'user' 
                ? 'bg-primary text-primary-foreground rounded-tl-none' 
                : 'bg-card border border-border rounded-tr-none'
            }`}>
              <div className="whitespace-pre-wrap leading-relaxed text-sm md:text-base">
                {msg.content}
              </div>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex gap-4">
            <div className="w-10 h-10 rounded-full bg-card border border-border text-primary flex items-center justify-center shrink-0">
              <Bot className="w-5 h-5" />
            </div>
            <div className="bg-card border border-border rounded-2xl rounded-tr-none p-4 flex items-center gap-2">
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
            </div>
          </div>
        )}

        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 text-red-500 p-4 rounded-lg flex items-center gap-3 border border-red-200 dark:border-red-800">
            <AlertCircle className="w-5 h-5" />
            <p className="text-sm">{error}</p>
          </div>
        )}
      </div>

      <div className="mt-auto shrink-0 bg-background pt-2">
        {messages.length === 1 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {suggestions.map((suggestion, idx) => (
              <button
                key={idx}
                onClick={() => setInput(suggestion)}
                className="text-xs md:text-sm px-3 py-2 rounded-full border border-primary/30 bg-primary/5 text-primary hover:bg-primary/10 transition-colors flex items-center gap-2"
              >
                <Sparkles className="w-3 h-3" />
                {suggestion}
              </button>
            ))}
          </div>
        )}

        <form onSubmit={handleSubmit} className="relative flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="اكتب سؤالك أو طلبك هنا..."
            className="w-full bg-card border border-border rounded-xl py-4 pr-4 pl-14 focus:outline-none focus:ring-2 focus:ring-primary/50 text-foreground"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary-gold-dark disabled:opacity-50 transition-colors"
          >
            <Send className="w-5 h-5 rtl:rotate-180" />
          </button>
        </form>
      </div>
    </div>
  );
}
