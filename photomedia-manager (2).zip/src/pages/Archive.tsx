import { FileArchive } from 'lucide-react';

export default function Archive() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <FileArchive className="w-6 h-6 text-primary" />
          الأرشيف
        </h1>
      </div>
      <div className="bg-card border border-border rounded-lg p-8 text-center text-foreground/60">المشاريع المؤرشفة...</div>
    </div>
  );
}
