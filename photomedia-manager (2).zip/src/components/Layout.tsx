import { ReactNode, useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { auth } from '../lib/firebase';
import { connectGoogleDrive, getDriveAccessToken } from '../lib/drive';
import {
  LayoutDashboard,
  Film,
  Calendar,
  Users,
  Camera,
  Briefcase,
  DollarSign,
  Lightbulb,
  Bot,
  Settings,
  LogOut,
  Menu,
  FileArchive,
  BarChart,
  HardDrive
} from 'lucide-react';
import { signOut } from 'firebase/auth';

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const { profile } = useAuthStore();
  const navigate = useNavigate();
  const [driveConnected, setDriveConnected] = useState(false);

  useEffect(() => {
    if (getDriveAccessToken()) {
      setDriveConnected(true);
    }
  }, []);

  const handleConnectDrive = async () => {
    try {
      await connectGoogleDrive();
      setDriveConnected(true);
    } catch (err) {
      console.error(err);
      alert('فشل في الاتصال بـ Google Drive');
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  const navItems = [
    { name: 'لوحة التحكم', path: '/', icon: LayoutDashboard },
    { name: 'المشاريع', path: '/projects', icon: Film },
    { name: 'التقويم', path: '/calendar', icon: Calendar },
    { name: 'العملاء', path: '/clients', icon: Briefcase },
    { name: 'فريق العمل', path: '/team', icon: Users },
    { name: 'المعدات', path: '/equipment', icon: Camera },
    { name: 'المالية', path: '/finances', icon: DollarSign },
    { name: 'بنك الأفكار', path: '/idea-bank', icon: Lightbulb },
    { name: 'المساعد الذكي (AI)', path: '/ai-assistant', icon: Bot },
    { name: 'التقارير', path: '/reports', icon: BarChart },
    { name: 'الأرشيف', path: '/archive', icon: FileArchive },
  ];

  return (
    <div className="flex h-screen bg-background overflow-hidden rtl">
      {/* Sidebar */}
      <aside className="w-64 bg-card border-l border-border flex flex-col h-full">
        <div className="p-6 flex items-center gap-3 border-b border-border">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center text-primary-foreground font-bold text-xl">
            P
          </div>
          <h1 className="font-bold text-xl text-primary">PhotoMedia</h1>
        </div>
        
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="space-y-1 px-3">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                    isActive
                      ? 'bg-primary/10 text-primary font-medium'
                      : 'text-foreground/70 hover:bg-border/50 hover:text-foreground'
                  }`
                }
              >
                <item.icon className="w-5 h-5" />
                <span>{item.name}</span>
              </NavLink>
            ))}
          </nav>
        </div>

        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-border flex items-center justify-center overflow-hidden">
              {profile?.photoURL ? (
                <img src={profile.photoURL} alt="User" className="w-full h-full object-cover" />
              ) : (
                <Users className="w-5 h-5 text-foreground/50" />
              )}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-medium truncate">{profile?.displayName || 'مستخدم'}</p>
              <p className="text-xs text-foreground/50 truncate">{profile?.role}</p>
            </div>
          </div>
          
          <button
            onClick={driveConnected ? undefined : handleConnectDrive}
            className={`flex items-center gap-2 mb-2 w-full px-3 py-2 rounded-md transition-colors ${
              driveConnected 
                ? 'text-green-500 bg-green-50 dark:bg-green-900/10 cursor-default'
                : 'text-foreground/70 hover:bg-border/50 hover:text-foreground'
            }`}
          >
            <HardDrive className="w-4 h-4" />
            <span className="text-sm">{driveConnected ? 'Google Drive متصل' : 'ربط Google Drive'}</span>
          </button>

          <button
            onClick={handleLogout}
            className="flex items-center gap-2 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 w-full px-3 py-2 rounded-md transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="h-16 bg-card border-b border-border flex items-center px-6 justify-between shrink-0">
          <button className="md:hidden text-foreground/70 hover:text-foreground">
            <Menu className="w-6 h-6" />
          </button>
          
          <div className="flex-1 flex justify-end">
             {/* Top right actions could go here */}
          </div>
        </header>
        
        <div className="flex-1 overflow-y-auto p-6 bg-background">
          {children}
        </div>
      </main>
    </div>
  );
}
