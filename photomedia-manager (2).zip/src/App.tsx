import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, updateDoc, setDoc } from 'firebase/firestore';
import { auth, db } from './lib/firebase';
import { useAuthStore } from './store/authStore';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import AIAssistant from './pages/AIAssistant';
import Projects from './pages/Projects';
import Calendar from './pages/Calendar';
import Clients from './pages/Clients';
import Team from './pages/Team';
import Equipment from './pages/Equipment';
import Finances from './pages/Finances';
import IdeaBank from './pages/IdeaBank';
import Reports from './pages/Reports';
import Archive from './pages/Archive';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuthStore();

  if (loading) {
    return <div className="h-screen flex items-center justify-center bg-background text-foreground">جاري التحميل...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

export default function App() {
  const { setUser, setProfile, setLoading } = useAuthStore();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const docRef = doc(db, 'users', currentUser.uid);
          const docSnap = await getDoc(docRef);
          
          if (docSnap.exists()) {
            let data = docSnap.data();
            
            // Auto-upgrade specific email to Super Admin
            if (currentUser.email === 'photomediiaa@gmail.com' && (data.role !== 'Super Admin' || !data.isActive)) {
              await updateDoc(docRef, { role: 'Super Admin', isActive: true });
              data = { ...data, role: 'Super Admin', isActive: true };
            }
            
            setProfile({ uid: currentUser.uid, ...data } as any);
          } else {
            // Auto-create document if it doesn't exist for the super admin
            if (currentUser.email === 'photomediiaa@gmail.com') {
              const newProfile = {
                uid: currentUser.uid,
                email: currentUser.email,
                displayName: 'Super Admin',
                role: 'Super Admin',
                isActive: true
              };
              await setDoc(docRef, newProfile);
              setProfile(newProfile as any);
            } else {
              setProfile(null);
            }
          }
        } catch (error) {
          console.error("Error fetching profile:", error);
          setProfile(null);
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [setUser, setProfile, setLoading]);

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        
        <Route path="/" element={
          <ProtectedRoute>
            <Layout>
              <Dashboard />
            </Layout>
          </ProtectedRoute>
        } />

        <Route path="/ai-assistant" element={
          <ProtectedRoute>
            <Layout>
              <AIAssistant />
            </Layout>
          </ProtectedRoute>
        } />
        
        <Route path="/projects" element={<ProtectedRoute><Layout><Projects /></Layout></ProtectedRoute>} />
        <Route path="/calendar" element={<ProtectedRoute><Layout><Calendar /></Layout></ProtectedRoute>} />
        <Route path="/clients" element={<ProtectedRoute><Layout><Clients /></Layout></ProtectedRoute>} />
        <Route path="/team" element={<ProtectedRoute><Layout><Team /></Layout></ProtectedRoute>} />
        <Route path="/equipment" element={<ProtectedRoute><Layout><Equipment /></Layout></ProtectedRoute>} />
        <Route path="/finances" element={<ProtectedRoute><Layout><Finances /></Layout></ProtectedRoute>} />
        <Route path="/idea-bank" element={<ProtectedRoute><Layout><IdeaBank /></Layout></ProtectedRoute>} />
        <Route path="/reports" element={<ProtectedRoute><Layout><Reports /></Layout></ProtectedRoute>} />
        <Route path="/archive" element={<ProtectedRoute><Layout><Archive /></Layout></ProtectedRoute>} />

        {/* Fallback route */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}
